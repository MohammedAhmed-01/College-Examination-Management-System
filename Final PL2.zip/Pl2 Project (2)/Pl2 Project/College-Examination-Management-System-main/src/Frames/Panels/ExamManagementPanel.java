package Frames.Panels;

import FCIHCaseStudy.Exam;
import FCIHCaseStudy.ExamDataManager;
import FCIHCaseStudy.Professor;
import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

/**
 * A comprehensive panel for managing exams (Add, Edit, Delete, List)
 * @author Cascade
 */
public class ExamManagementPanel extends javax.swing.JInternalFrame {

    private Professor currentProfessor;
    private CardLayout cardLayout;
    private JPanel cardsPanel;
    private JPanel listPanel;
    private JPanel addEditPanel;
    
    // List Panel Components
    private JTable examsTable;
    private DefaultTableModel tableModel;
    private JButton addNewButton;
    private JButton editButton;
    private JButton deleteButton;
    private JButton refreshButton;
    private JButton importButton;
    private JButton exportButton;
    
    // Add/Edit Panel Components
    private JTextField examIdField;
    private JTextField examNameField;
    private JTextField subjectField;
    private JSpinner durationSpinner;
    private JSpinner maxGradeSpinner;
    
    private JTextArea q1Area;
    private JTextArea q2Area;
    private JTextArea q3Area;
    private JTextArea q4Area;
    
    private JTextField correctAnswer1Field;
    private JTextField correctAnswer2Field;
    private JTextField correctAnswer3Field;
    private JTextField correctAnswer4Field;
    
    private JButton saveButton;
    private JButton cancelButton;
    
    private boolean isEditMode = false;
    private String currentExamId = null;

    /**
     * Creates new form ExamManagementPanel
     */
    public ExamManagementPanel() {
        initComponents();
        setupUI();
    }
    
    /**
     * Creates new form ExamManagementPanel with a professor
     * @param professor The professor using this panel
     */
    public ExamManagementPanel(Professor professor) {
        initComponents();
        this.currentProfessor = professor;
        setupUI();
    }
    
    private void setupUI() {
        setTitle("Exam Management");
        setClosable(true);
        setMaximizable(true);
        setResizable(true);
        setSize(800, 600);
        
        // Create the card layout and panel
        cardLayout = new CardLayout();
        cardsPanel = new JPanel(cardLayout);
        
        // Setup the list panel
        setupListPanel();
        
        // Setup the add/edit panel
        setupAddEditPanel();
        
        // Add panels to the card layout
        cardsPanel.add(listPanel, "list");
        cardsPanel.add(addEditPanel, "addEdit");
        
        // Show the list panel by default
        cardLayout.show(cardsPanel, "list");
        
        // Add the cards panel to the frame
        getContentPane().add(cardsPanel);
        
        // Load exams
        refreshExamsList();
    }
    
    private void setupListPanel() {
        listPanel = new JPanel();
        listPanel.setLayout(null); // Absolute positioning
        
        // Create the table model with columns
        tableModel = new DefaultTableModel(
                new Object[][]{},
                new String[]{"ID", "Name", "Subject", "Duration (min)", "Max Grade"}
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table non-editable
            }
        };
        
        // Create the table
        examsTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(examsTable);
        scrollPane.setBounds(20, 20, 740, 400);
        listPanel.add(scrollPane);
        
        // Add selection listener to enable/disable edit and delete buttons
        examsTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                boolean hasSelection = examsTable.getSelectedRow() != -1;
                editButton.setEnabled(hasSelection);
                deleteButton.setEnabled(hasSelection);
            }
        });
        
        // Create buttons
        addNewButton = new JButton("Add New Exam");
        addNewButton.setBounds(20, 440, 150, 30);
        addNewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                isEditMode = false;
                clearAddEditForm();
                cardLayout.show(cardsPanel, "addEdit");
            }
        });
        
        editButton = new JButton("Edit Selected");
        editButton.setBounds(180, 440, 150, 30);
        editButton.setEnabled(false);
        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = examsTable.getSelectedRow();
                if (selectedRow != -1) {
                    String examId = (String) examsTable.getValueAt(selectedRow, 0);
                    loadExamForEditing(examId);
                }
            }
        });
        
        deleteButton = new JButton("Delete Selected");
        deleteButton.setBounds(340, 440, 150, 30);
        deleteButton.setEnabled(false);
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteSelectedExam();
            }
        });
        
        refreshButton = new JButton("Refresh List");
        refreshButton.setBounds(500, 440, 150, 30);
        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                refreshExamsList();
            }
        });
        
        // Import/Export buttons
        importButton = new JButton("Import Exams");
        importButton.setBounds(180, 480, 150, 30);
        importButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                importExams();
            }
        });
        
        exportButton = new JButton("Export Exams");
        exportButton.setBounds(340, 480, 150, 30);
        exportButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exportExams();
            }
        });
        
        // Add buttons to panel
        listPanel.add(addNewButton);
        listPanel.add(editButton);
        listPanel.add(deleteButton);
        listPanel.add(refreshButton);
        listPanel.add(importButton);
        listPanel.add(exportButton);
    }
    
    private void setupAddEditPanel() {
        addEditPanel = new JPanel();
        addEditPanel.setLayout(null); // Absolute positioning
        
        // Create form labels and fields
        JLabel idLabel = new JLabel("Exam ID:");
        idLabel.setBounds(20, 20, 100, 25);
        examIdField = new JTextField();
        examIdField.setBounds(130, 20, 200, 25);
        
        JLabel nameLabel = new JLabel("Exam Name:");
        nameLabel.setBounds(20, 50, 100, 25);
        examNameField = new JTextField();
        examNameField.setBounds(130, 50, 200, 25);
        
        JLabel subjectLabel = new JLabel("Subject:");
        subjectLabel.setBounds(20, 80, 100, 25);
        subjectField = new JTextField();
        subjectField.setBounds(130, 80, 200, 25);
        
        JLabel durationLabel = new JLabel("Duration (min):");
        durationLabel.setBounds(350, 20, 100, 25);
        durationSpinner = new JSpinner(new SpinnerNumberModel(60, 15, 180, 5));
        durationSpinner.setBounds(460, 20, 100, 25);
        
        JLabel maxGradeLabel = new JLabel("Max Grade:");
        maxGradeLabel.setBounds(350, 50, 100, 25);
        maxGradeSpinner = new JSpinner(new SpinnerNumberModel(20, 5, 100, 5));
        maxGradeSpinner.setBounds(460, 50, 100, 25);
        
        // Questions
        JLabel q1Label = new JLabel("Question 1:");
        q1Label.setBounds(20, 120, 100, 25);
        q1Area = new JTextArea();
        JScrollPane q1Scroll = new JScrollPane(q1Area);
        q1Scroll.setBounds(20, 150, 350, 60);
        
        JLabel correctAnswer1Label = new JLabel("Correct Answer 1:");
        correctAnswer1Label.setBounds(380, 150, 120, 25);
        correctAnswer1Field = new JTextField();
        correctAnswer1Field.setBounds(500, 150, 200, 25);
        
        JLabel q2Label = new JLabel("Question 2:");
        q2Label.setBounds(20, 220, 100, 25);
        q2Area = new JTextArea();
        JScrollPane q2Scroll = new JScrollPane(q2Area);
        q2Scroll.setBounds(20, 250, 350, 60);
        
        JLabel correctAnswer2Label = new JLabel("Correct Answer 2:");
        correctAnswer2Label.setBounds(380, 250, 120, 25);
        correctAnswer2Field = new JTextField();
        correctAnswer2Field.setBounds(500, 250, 200, 25);
        
        JLabel q3Label = new JLabel("Question 3:");
        q3Label.setBounds(20, 320, 100, 25);
        q3Area = new JTextArea();
        JScrollPane q3Scroll = new JScrollPane(q3Area);
        q3Scroll.setBounds(20, 350, 350, 60);
        
        JLabel correctAnswer3Label = new JLabel("Correct Answer 3:");
        correctAnswer3Label.setBounds(380, 350, 120, 25);
        correctAnswer3Field = new JTextField();
        correctAnswer3Field.setBounds(500, 350, 200, 25);
        
        JLabel q4Label = new JLabel("Question 4:");
        q4Label.setBounds(20, 420, 100, 25);
        q4Area = new JTextArea();
        JScrollPane q4Scroll = new JScrollPane(q4Area);
        q4Scroll.setBounds(20, 450, 350, 60);
        
        JLabel correctAnswer4Label = new JLabel("Correct Answer 4:");
        correctAnswer4Label.setBounds(380, 450, 120, 25);
        correctAnswer4Field = new JTextField();
        correctAnswer4Field.setBounds(500, 450, 200, 25);
        
        // Buttons
        saveButton = new JButton("Save Exam");
        saveButton.setBounds(250, 530, 120, 30);
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveExam();
            }
        });
        
        cancelButton = new JButton("Cancel");
        cancelButton.setBounds(380, 530, 120, 30);
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(cardsPanel, "list");
            }
        });
        
        // Add components to panel
        addEditPanel.add(idLabel);
        addEditPanel.add(examIdField);
        addEditPanel.add(nameLabel);
        addEditPanel.add(examNameField);
        addEditPanel.add(subjectLabel);
        addEditPanel.add(subjectField);
        addEditPanel.add(durationLabel);
        addEditPanel.add(durationSpinner);
        addEditPanel.add(maxGradeLabel);
        addEditPanel.add(maxGradeSpinner);
        
        addEditPanel.add(q1Label);
        addEditPanel.add(q1Scroll);
        addEditPanel.add(correctAnswer1Label);
        addEditPanel.add(correctAnswer1Field);
        
        addEditPanel.add(q2Label);
        addEditPanel.add(q2Scroll);
        addEditPanel.add(correctAnswer2Label);
        addEditPanel.add(correctAnswer2Field);
        
        addEditPanel.add(q3Label);
        addEditPanel.add(q3Scroll);
        addEditPanel.add(correctAnswer3Label);
        addEditPanel.add(correctAnswer3Field);
        
        addEditPanel.add(q4Label);
        addEditPanel.add(q4Scroll);
        addEditPanel.add(correctAnswer4Label);
        addEditPanel.add(correctAnswer4Field);
        
        addEditPanel.add(saveButton);
        addEditPanel.add(cancelButton);
    }
    
    private void refreshExamsList() {
        // Clear the table
        tableModel.setRowCount(0);
        
        // Load all exams using the professor's method
        ArrayList<Exam> exams = new ArrayList<>();
        try {
            if (currentProfessor != null) {
                exams = currentProfessor.getAllExams();
            } else {
                // Fallback to direct method if professor is not available
                Exam examObj = new Exam();
                examObj.loadFromFile(); // Ensure the file is loaded
                exams = examObj.getAllExams();
            }
            
            // If exams list is still empty, initialize the file
            if (exams.isEmpty()) {
                initializeExamsFile();
                if (currentProfessor != null) {
                    exams = currentProfessor.getAllExams();
                } else {
                    Exam examObj = new Exam();
                    examObj.loadFromFile();
                    exams = examObj.getAllExams();
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error loading exams: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            // Initialize an empty list if there's an error
            exams = new ArrayList<>();
            initializeExamsFile();
        }
        
        // Add exams to the table
        for (Exam exam : exams) {
            tableModel.addRow(new Object[]{
                exam.getEId(),
                exam.getEName(),
                exam.getSubjectName(),
                exam.getDuration(),
                exam.getMaxGrade()
            });
        }
        
        // Disable edit and delete buttons
        editButton.setEnabled(false);
        deleteButton.setEnabled(false);
    }
    /**
     * Save the current exam (add new or update existing)
     */
    private void saveExam() {
        try {
            // Validate input
            String id = examIdField.getText().trim();
            String name = examNameField.getText().trim();
            String subject = subjectField.getText().trim();
            int duration = (Integer) durationSpinner.getValue();
            double maxGrade = ((Number) maxGradeSpinner.getValue()).doubleValue();
            String q1 = q1Area.getText().trim();
            String q2 = q2Area.getText().trim();
            String q3 = q3Area.getText().trim();
            String q4 = q4Area.getText().trim();
            String a1 = correctAnswer1Field.getText().trim();
            String a2 = correctAnswer2Field.getText().trim();
            String a3 = correctAnswer3Field.getText().trim();
            String a4 = correctAnswer4Field.getText().trim();
            
            // Validate required fields
            if (id.isEmpty() || name.isEmpty() || subject.isEmpty() || 
                q1.isEmpty() || q2.isEmpty() || q3.isEmpty() || q4.isEmpty() ||
                a1.isEmpty() || a2.isEmpty() || a3.isEmpty() || a4.isEmpty()) {
                JOptionPane.showMessageDialog(this, 
                    "All fields are required.", 
                    "Validation Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Create or update exam
            Exam exam = new Exam(name, id, maxGrade, q1, q2, q3, q4, a1, a2, a3, a4, duration, subject);
            
            boolean success;
            if (isEditMode) {
                // Update existing exam
                success = currentProfessor != null ? 
                    currentProfessor.updateExam(exam) : 
                    exam.updateExam();
                
                if (success) {
                    JOptionPane.showMessageDialog(this, 
                        "Exam updated successfully.", 
                        "Success", 
                        JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, 
                        "Failed to update exam.", 
                        "Error", 
                        JOptionPane.ERROR_MESSAGE);
                    return;
                }
            } else {
                // Add new exam
                success = currentProfessor != null ? 
                    currentProfessor.addExam(exam) : 
                    exam.addExam();
                
                if (success) {
                    JOptionPane.showMessageDialog(this, 
                        "Exam added successfully.", 
                        "Success", 
                        JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, 
                        "Failed to add exam. ID may already exist.", 
                        "Error", 
                        JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }
            
            // Return to list view and refresh
            cardLayout.show(cardsPanel, "list");
            refreshExamsList();
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, 
                "Invalid number format in one of the fields.", 
                "Input Error", 
                JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error saving exam: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Load an exam for editing
     * @param examId The ID of the exam to edit
     */
    private void loadExamForEditing(String examId) {
        try {
            // Get the exam
            Exam exam = currentProfessor != null ? 
                currentProfessor.getExamById(examId) : 
                new Exam().searchExamById(examId);
            
            if (exam == null) {
                JOptionPane.showMessageDialog(this, 
                    "Exam not found.", 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Set edit mode
            isEditMode = true;
            currentExamId = examId;
            
            // Populate form fields
            examIdField.setText(exam.getEId());
            examIdField.setEditable(false); // ID should not be changed
            examNameField.setText(exam.getEName());
            subjectField.setText(exam.getSubjectName());
            durationSpinner.setValue(exam.getDuration());
            maxGradeSpinner.setValue(exam.getMaxGrade());
            
            q1Area.setText(exam.getQ1());
            q2Area.setText(exam.getQ2());
            q3Area.setText(exam.getQ3());
            q4Area.setText(exam.getQ4());
            
            correctAnswer1Field.setText(exam.getCorrectAnswer1());
            correctAnswer2Field.setText(exam.getCorrectAnswer2());
            correctAnswer3Field.setText(exam.getCorrectAnswer3());
            correctAnswer4Field.setText(exam.getCorrectAnswer4());
            
            // Show the edit form
            cardLayout.show(cardsPanel, "addEdit");
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error loading exam: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Clear the add/edit form fields
     */
    private void clearAddEditForm() {
        examIdField.setText("");
        examIdField.setEditable(true);
        examNameField.setText("");
        subjectField.setText("");
        durationSpinner.setValue(60);
        maxGradeSpinner.setValue(20);
        
        q1Area.setText("");
        q2Area.setText("");
        q3Area.setText("");
        q4Area.setText("");
        
        correctAnswer1Field.setText("");
        correctAnswer2Field.setText("");
        correctAnswer3Field.setText("");
        correctAnswer4Field.setText("");
    }
    
    /**
     * Delete the selected exam
     */
    private void deleteSelectedExam() {
        int selectedRow = examsTable.getSelectedRow();
        if (selectedRow != -1) {
            String examId = (String) examsTable.getValueAt(selectedRow, 0);
            
            int confirm = JOptionPane.showConfirmDialog(this, 
                "Are you sure you want to delete exam " + examId + "?", 
                "Confirm Deletion", 
                JOptionPane.YES_NO_OPTION);
            
            if (confirm == JOptionPane.YES_OPTION) {
                boolean success = currentProfessor != null ? 
                    currentProfessor.deleteExam(examId) : 
                    new Exam().searchExamById(examId).deleteExam();
                
                if (success) {
                    JOptionPane.showMessageDialog(this, 
                        "Exam deleted successfully.", 
                        "Success", 
                        JOptionPane.INFORMATION_MESSAGE);
                    refreshExamsList();
                } else {
                    JOptionPane.showMessageDialog(this, 
                        "Failed to delete exam.", 
                        "Error", 
                        JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }
    
    /**
     * Import exams from a CSV file
     */
    private void importExams() {
        ArrayList<Exam> importedExams = ExamDataManager.importExamsFromCSV();
        
        if (importedExams != null && !importedExams.isEmpty()) {
            int successCount = 0;
            
            for (Exam exam : importedExams) {
                boolean success = currentProfessor != null ? 
                    currentProfessor.addExam(exam) : 
                    exam.addExam();
                
                if (success) {
                    successCount++;
                }
            }
            
            JOptionPane.showMessageDialog(this, 
                successCount + " out of " + importedExams.size() + " exams imported successfully.", 
                "Import Results", 
                JOptionPane.INFORMATION_MESSAGE);
            
            refreshExamsList();
        }
    }
    
    /**
     * Export exams to a CSV file
     */
    private void exportExams() {
        ArrayList<Exam> exams = currentProfessor != null ? 
            currentProfessor.getAllExams() : 
            new Exam().getAllExams();
        
        if (exams.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "No exams to export.", 
                "Export Error", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        boolean success = ExamDataManager.exportExamsToCSV(exams);
        
        if (!success) {
            JOptionPane.showMessageDialog(this, 
                "Export was cancelled or failed.", 
                "Export Status", 
                JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    private void initializeExamsFile() {
        try {
            System.out.println("Initializing exams file...");
            Exam exam = new Exam();
            exam.loadFromFile();
            
            ArrayList<Exam> existingExams = exam.getAllExams();
            System.out.println("Found " + existingExams.size() + " existing exams");
            
            if (existingExams.isEmpty()) {
                System.out.println("No exams found. Adding sample exam...");
                // Add a sample exam
                Exam sampleExam = new Exam(
                    "Java Basics", 
                    "EXAM001", 
                    20, 
                    "What is Java?", 
                    "What does OOP stand for?", 
                    "How many classes can you add in a Java program?", 
                    "How many frames can you add in a Java program?",
                    "Programming language",
                    "Object Oriented Programming",
                    "Unlimited",
                    "Unlimited",
                    60,
                    "Programming 101"
                );
                
                boolean success = sampleExam.addExam();
                if (success) {
                    System.out.println("Sample exam added successfully");
                } else {
                    System.out.println("Failed to add sample exam");
                }
            }
        } catch (Exception e) {
            System.out.println("Error initializing exams file: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Exam Management");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 800, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 600, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
