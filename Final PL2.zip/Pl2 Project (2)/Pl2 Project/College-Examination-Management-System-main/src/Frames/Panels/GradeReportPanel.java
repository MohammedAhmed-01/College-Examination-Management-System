package Frames.Panels;

import FCIHCaseStudy.Exam;
import FCIHCaseStudy.Grade;
import FCIHCaseStudy.Professor;
import FCIHCaseStudy.Student;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 * A panel for generating reports about students and their grades
 * @author Cascade
 */
public class GradeReportPanel extends javax.swing.JInternalFrame {

    private Professor currentProfessor;
    private JPanel controlPanel;
    private JTable reportTable;
    private DefaultTableModel tableModel;
    
    private JComboBox<String> reportTypeCombo;
    private JTextField studentIdField;
    private JComboBox<String> examComboBox;
    
    /**
     * Creates new form GradeReportPanel
     */
    public GradeReportPanel() {
        initComponents();
        setupUI();
    }
    
    /**
     * Creates new form GradeReportPanel with a professor
     * @param professor The professor using this panel
     */
    public GradeReportPanel(Professor professor) {
        initComponents();
        this.currentProfessor = professor;
        setupUI();
    }
    
    private void setupUI() {
        setTitle("Grade Reports");
        setClosable(true);
        setMaximizable(true);
        setResizable(true);
        setSize(800, 600);
        
        // Set up the main layout
        getContentPane().setLayout(new BorderLayout());
        
        // Create the control panel
        setupControlPanel();
        getContentPane().add(controlPanel, BorderLayout.NORTH);
        
        // Create the table model with columns
        tableModel = new DefaultTableModel(
                new Object[][]{},
                new String[]{"Student ID", "Student Name", "Exam ID", "Exam Name", "Grade", "Max Grade", "Percentage"}
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table non-editable
            }
        };
        
        // Create the table
        reportTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(reportTable);
        getContentPane().add(scrollPane, BorderLayout.CENTER);
        
        // Load all exams for the combo box
        loadExamsIntoComboBox();
    }
    
    private void setupControlPanel() {
        controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        
        // Report type selector
        JLabel reportTypeLabel = new JLabel("Report Type:");
        reportTypeCombo = new JComboBox<>(new String[]{
            "All Grades", 
            "Student Grades", 
            "Exam Grades"
        });
        
        // Student ID field
        JLabel studentIdLabel = new JLabel("Student ID:");
        studentIdField = new JTextField(10);
        studentIdField.setEnabled(false);
        
        // Exam selector
        JLabel examLabel = new JLabel("Exam:");
        examComboBox = new JComboBox<>();
        examComboBox.setEnabled(false);
        
        // Generate report button
        JButton generateButton = new JButton("Generate Report");
        
        // Add action listener to report type combo to enable/disable fields
        reportTypeCombo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedType = (String) reportTypeCombo.getSelectedItem();
                
                if ("Student Grades".equals(selectedType)) {
                    studentIdField.setEnabled(true);
                    examComboBox.setEnabled(false);
                } else if ("Exam Grades".equals(selectedType)) {
                    studentIdField.setEnabled(false);
                    examComboBox.setEnabled(true);
                } else { // All Grades
                    studentIdField.setEnabled(false);
                    examComboBox.setEnabled(false);
                }
            }
        });
        
        // Add action listener to generate button
        generateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generateReport();
            }
        });
        
        // Add components to control panel
        controlPanel.add(reportTypeLabel);
        controlPanel.add(reportTypeCombo);
        controlPanel.add(studentIdLabel);
        controlPanel.add(studentIdField);
        controlPanel.add(examLabel);
        controlPanel.add(examComboBox);
        controlPanel.add(generateButton);
        
        // Add export button
        JButton exportButton = new JButton("Export to CSV");
        exportButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exportToCSV();
            }
        });
        controlPanel.add(exportButton);
    }
    
    private void loadExamsIntoComboBox() {
        examComboBox.removeAllItems();
        
        // Add a "Select Exam" option
        examComboBox.addItem("-- Select Exam --");
        
        // Load all exams
        Exam examObj = new Exam();
        ArrayList<Exam> exams = examObj.getAllExams();
        
        // Add exams to the combo box
        for (Exam exam : exams) {
            examComboBox.addItem(exam.getEId() + " - " + exam.getEName());
        }
    }
    
    private void generateReport() {
        // Clear the table
        tableModel.setRowCount(0);
        
        String reportType = (String) reportTypeCombo.getSelectedItem();
        
        if ("All Grades".equals(reportType)) {
            generateAllGradesReport();
        } else if ("Student Grades".equals(reportType)) {
            generateStudentGradesReport();
        } else if ("Exam Grades".equals(reportType)) {
            generateExamGradesReport();
        }
    }
    
    private void generateAllGradesReport() {
        if (currentProfessor == null) {
            JOptionPane.showMessageDialog(this, 
                "No professor is logged in. Cannot generate report.", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        ArrayList<Grade> allGrades = currentProfessor.getAllGrades();
        populateTableWithGrades(allGrades);
    }
    
    private void generateStudentGradesReport() {
        if (currentProfessor == null) {
            JOptionPane.showMessageDialog(this, 
                "No professor is logged in. Cannot generate report.", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        String studentIdStr = studentIdField.getText().trim();
        if (studentIdStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please enter a student ID.", 
                "Validation Error", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            int studentId = Integer.parseInt(studentIdStr);
            
            // Validate student exists
            Student student = new Student().searchStudentById(studentId);
            if (student.getID() == 0) {
                JOptionPane.showMessageDialog(this, 
                    "Student with ID " + studentId + " not found.", 
                    "Not Found", 
                    JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            ArrayList<Grade> studentGrades = currentProfessor.getStudentGrades(studentId);
            populateTableWithGrades(studentGrades);
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, 
                "Student ID must be a number.", 
                "Validation Error", 
                JOptionPane.WARNING_MESSAGE);
        }
    }
    
    private void generateExamGradesReport() {
        if (currentProfessor == null) {
            JOptionPane.showMessageDialog(this, 
                "No professor is logged in. Cannot generate report.", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        int selectedIndex = examComboBox.getSelectedIndex();
        if (selectedIndex <= 0) { // Not selected or first item (-- Select Exam --)
            JOptionPane.showMessageDialog(this, 
                "Please select an exam.", 
                "Validation Error", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String selectedExam = (String) examComboBox.getSelectedItem();
        String examId = selectedExam.split(" - ")[0]; // Extract exam ID from the combo box item
        
        ArrayList<Grade> examGrades = currentProfessor.getExamGrades(examId);
        populateTableWithGrades(examGrades);
    }
    
    private void populateTableWithGrades(ArrayList<Grade> grades) {
        if (grades.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "No grades found for the selected criteria.", 
                "No Data", 
                JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        
        for (Grade grade : grades) {
            // Get student info
            Student student = new Student().searchStudentById(grade.getStudentId());
            String studentName = (student.getID() != 0) ? 
                student.getFName() + " " + student.getLName() : "Unknown";
            
            // Get exam info
            Exam exam = new Exam().searchExamById(grade.getExamId());
            String examName = (exam != null) ? exam.getEName() : "Unknown";
            double maxGrade = (exam != null) ? exam.getMaxGrade() : 0;
            
            // Calculate percentage
            double percentage = (maxGrade > 0) ? (grade.getGrade() / maxGrade) * 100 : 0;
            
            // Add row to table
            tableModel.addRow(new Object[]{
                grade.getStudentId(),
                studentName,
                grade.getExamId(),
                examName,
                grade.getGrade(),
                maxGrade,
                String.format("%.2f%%", percentage)
            });
        }
    }
    
    private void exportToCSV() {
        if (tableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, 
                "No data to export. Generate a report first.", 
                "No Data", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            // Create a StringBuilder for the CSV content
            StringBuilder csvContent = new StringBuilder();
            
            // Add header row
            for (int i = 0; i < tableModel.getColumnCount(); i++) {
                csvContent.append(tableModel.getColumnName(i));
                if (i < tableModel.getColumnCount() - 1) {
                    csvContent.append(",");
                }
            }
            csvContent.append("\n");
            
            // Add data rows
            for (int row = 0; row < tableModel.getRowCount(); row++) {
                for (int col = 0; col < tableModel.getColumnCount(); col++) {
                    Object value = tableModel.getValueAt(row, col);
                    csvContent.append(value != null ? value.toString() : "");
                    if (col < tableModel.getColumnCount() - 1) {
                        csvContent.append(",");
                    }
                }
                csvContent.append("\n");
            }
            
            // For simplicity, we'll just show the CSV content in a message dialog
            // In a real application, you would save this to a file
            JOptionPane.showMessageDialog(this, 
                "CSV Export:\n\n" + csvContent.toString(), 
                "CSV Export", 
                JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error exporting to CSV: " + e.getMessage(), 
                "Export Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Grade Reports");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 800, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 600, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
