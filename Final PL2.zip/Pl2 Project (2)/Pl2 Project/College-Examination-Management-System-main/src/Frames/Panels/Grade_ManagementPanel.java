package Frames.Panels;

import FCIHCaseStudy.*;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Panel for managing student grades
 */
public class Grade_ManagementPanel extends javax.swing.JInternalFrame {

    private Professor professor;
    private JTable gradesTable;
    private DefaultTableModel tableModel;
    private JTextField studentIdField, examIdField, gradeField;
    private JButton addButton, deleteButton, showAllButton, showByStudentButton, showByExamButton;
    private JPanel controlPanel, tablePanel;
    private JScrollPane scrollPane;
    
    /**
     * Creates new form Grade_ManagementPanel
     */
    public Grade_ManagementPanel() {
        initComponents();
        professor = new Professor();
    }
    
    /**
     * Creates new form Grade_ManagementPanel with a specific professor
     * @param professor The logged-in professor
     */
    public Grade_ManagementPanel(Professor professor) {
        initComponents();
        if (professor != null) {
            this.professor = professor;
        } else {
            this.professor = new Professor();
        }
    }
    
    private void initComponents() {
        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Grade Management");
        setBounds(0, 0, 800, 500);
        
        // Create main layout
        getContentPane().setLayout(new BorderLayout(10, 10));
        
        // Create control panel with input fields and buttons
        controlPanel = new JPanel(new GridBagLayout());
        controlPanel.setBorder(BorderFactory.createTitledBorder("Grade Controls"));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        
        // Student ID
        gbc.gridx = 0;
        gbc.gridy = 0;
        controlPanel.add(new JLabel("Student ID:"), gbc);
        
        gbc.gridx = 1;
        studentIdField = new JTextField(10);
        controlPanel.add(studentIdField, gbc);
        
        // Exam ID
        gbc.gridx = 0;
        gbc.gridy = 1;
        controlPanel.add(new JLabel("Exam ID:"), gbc);
        
        gbc.gridx = 1;
        examIdField = new JTextField(10);
        controlPanel.add(examIdField, gbc);
        
        // Grade
        gbc.gridx = 0;
        gbc.gridy = 2;
        controlPanel.add(new JLabel("Grade:"), gbc);
        
        gbc.gridx = 1;
        gradeField = new JTextField(10);
        controlPanel.add(gradeField, gbc);
        
        // Buttons
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        
        addButton = new JButton("Add/Update Grade");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addGrade();
            }
        });
        buttonPanel.add(addButton);
        
        deleteButton = new JButton("Delete Grade");
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteGrade();
            }
        });
        buttonPanel.add(deleteButton);
        
        controlPanel.add(buttonPanel, gbc);
        
        // View buttons
        gbc.gridy = 4;
        JPanel viewButtonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        
        showAllButton = new JButton("Show All Grades");
        showAllButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showAllGrades();
            }
        });
        viewButtonPanel.add(showAllButton);
        
        showByStudentButton = new JButton("Show Student Grades");
        showByStudentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showStudentGrades();
            }
        });
        viewButtonPanel.add(showByStudentButton);
        
        showByExamButton = new JButton("Show Exam Grades");
        showByExamButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showExamGrades();
            }
        });
        viewButtonPanel.add(showByExamButton);
        
        controlPanel.add(viewButtonPanel, gbc);
        
        // Add control panel to the top
        getContentPane().add(controlPanel, BorderLayout.NORTH);
        
        // Create table for displaying grades
        tableModel = new DefaultTableModel(
                new Object[][]{},
                new String[]{"Student ID", "Student Name", "Exam ID", "Grade"}
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table cells non-editable
            }
        };
        
        gradesTable = new JTable(tableModel);
        scrollPane = new JScrollPane(gradesTable);
        
        tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createTitledBorder("Grades"));
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        // Add table panel to the center
        getContentPane().add(tablePanel, BorderLayout.CENTER);
    }
    
    private void addGrade() {
        try {
            int studentId = Integer.parseInt(studentIdField.getText().trim());
            String examId = examIdField.getText().trim();
            double grade = Double.parseDouble(gradeField.getText().trim());
            
            if (examId.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter an exam ID", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            boolean success = professor.addGrade(studentId, examId, grade);
            
            if (success) {
                JOptionPane.showMessageDialog(this, "Grade added/updated successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                clearFields();
                showAllGrades(); // Refresh the table
            } else {
                JOptionPane.showMessageDialog(this, "Failed to add grade. Check if student exists and grade is valid.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers for Student ID and Grade", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void deleteGrade() {
        try {
            int studentId = Integer.parseInt(studentIdField.getText().trim());
            String examId = examIdField.getText().trim();
            
            if (examId.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter an exam ID", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            boolean success = professor.deleteGrade(studentId, examId);
            
            if (success) {
                JOptionPane.showMessageDialog(this, "Grade deleted successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                clearFields();
                showAllGrades(); // Refresh the table
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete grade. Grade not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid Student ID", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void showAllGrades() {
        ArrayList<Grade> grades = professor.getAllGrades();
        displayGrades(grades);
    }
    
    private void showStudentGrades() {
        try {
            int studentId = Integer.parseInt(studentIdField.getText().trim());
            ArrayList<Grade> grades = professor.getStudentGrades(studentId);
            
            if (grades.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No grades found for this student", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
            
            displayGrades(grades);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid Student ID", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void showExamGrades() {
        String examId = examIdField.getText().trim();
        
        if (examId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter an exam ID", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        ArrayList<Grade> grades = professor.getExamGrades(examId);
        
        if (grades.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No grades found for this exam", "Information", JOptionPane.INFORMATION_MESSAGE);
        }
        
        displayGrades(grades);
    }
    
    private void displayGrades(ArrayList<Grade> grades) {
        // Clear existing table data
        tableModel.setRowCount(0);
        
        // Add grades to the table
        for (Grade grade : grades) {
            Student student = new Student().searchStudentById(grade.getStudentId());
            String studentName = student.getFName() + " " + student.getLName();
            
            tableModel.addRow(new Object[]{
                grade.getStudentId(),
                studentName,
                grade.getExamId(),
                grade.getGrade()
            });
        }
    }
    
    private void clearFields() {
        studentIdField.setText("");
        examIdField.setText("");
        gradeField.setText("");
    }
}
