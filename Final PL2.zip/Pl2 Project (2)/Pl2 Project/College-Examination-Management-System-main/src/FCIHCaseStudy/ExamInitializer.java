package FCIHCaseStudy;

import java.util.ArrayList;

/**
 * Utility class to initialize the Exams.bin file with sample data
 */
public class ExamInitializer {
    public static void main(String[] args) {
        System.out.println("Initializing Exams.bin file with sample data...");
        
        // Create a new FileMangerBinary instance
        FileMangerBinary fileManger = new FileMangerBinary();
        
        // Create an ArrayList of Exams with sample data
        ArrayList<Exam> exams = new ArrayList<>();
        
        // Add sample exams
        Exam javaExam = new Exam(
            "Java Basics", 
            "EXAM001", 
            20, 
            "What is Java?", 
            "What does OOP stand for?", 
            "How many classes can you add in a Java program?", 
            "How many frames can you add in a Java program?",
            "Programming language",
            "Object Oriented Programming",
            "Unlimited",
            "Unlimited",
            60,
            "Programming 101"
        );
        exams.add(javaExam);
        
        Exam databaseExam = new Exam(
            "Database Fundamentals", 
            "EXAM002", 
            25, 
            "What is SQL?", 
            "What is a primary key?", 
            "What is normalization?", 
            "What is a foreign key?",
            "Structured Query Language",
            "A unique identifier for a record",
            "Process of organizing data to reduce redundancy",
            "A field that links to a primary key in another table",
            90,
            "Database Systems"
        );
        exams.add(databaseExam);
        
        // Write the exams list to the Exams.bin file
        boolean success = fileManger.write("Exams.bin", exams);
        
        if (success) {
            System.out.println("Exams.bin file created successfully with " + exams.size() + " sample exams!");
        } else {
            System.out.println("Failed to create Exams.bin file.");
        }
    }
    
    /**
     * Initialize the exams file with sample data if it doesn't exist or is empty
     * @return true if initialization was successful or not needed, false otherwise
     */
    public static boolean initializeIfNeeded() {
        try {
            // Check if exams file exists and has data
            Exam exam = new Exam();
            exam.loadFromFile();
            ArrayList<Exam> existingExams = exam.getAllExams();
            
            if (existingExams == null || existingExams.isEmpty()) {
                System.out.println("Exams file is empty or doesn't exist. Initializing with sample data...");
                
                // Create sample exams
                Exam javaExam = new Exam(
                    "Java Basics", 
                    "EXAM001", 
                    20, 
                    "What is Java?", 
                    "What does OOP stand for?", 
                    "How many classes can you add in a Java program?", 
                    "How many frames can you add in a Java program?",
                    "Programming language",
                    "Object Oriented Programming",
                    "Unlimited",
                    "Unlimited",
                    60,
                    "Programming 101"
                );
                javaExam.addExam();
                
                Exam databaseExam = new Exam(
                    "Database Fundamentals", 
                    "EXAM002", 
                    25, 
                    "What is SQL?", 
                    "What is a primary key?", 
                    "What is normalization?", 
                    "What is a foreign key?",
                    "Structured Query Language",
                    "A unique identifier for a record",
                    "Process of organizing data to reduce redundancy",
                    "A field that links to a primary key in another table",
                    90,
                    "Database Systems"
                );
                databaseExam.addExam();
                
                return true;
            }
            
            return true; // No initialization needed
        } catch (Exception e) {
            System.out.println("Error initializing exams file: " + e.getMessage());
            return false;
        }
    }
}
