package FCIHCaseStudy;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Represents a grade for a student in an exam
 */
public class Grade implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private int studentId;
    private String examId;
    private double grade;
    
    private static final String gradeFileName = "Grades.bin";
    public static ArrayList<Grade> Grades = new ArrayList<Grade>();
    private static FileMangerBinary FManger = new FileMangerBinary();
    
    public Grade() {
    }
    
    public Grade(int studentId, String examId, double grade) {
        this.studentId = studentId;
        this.examId = examId;
        this.grade = grade;
    }
    
    public int getStudentId() {
        return studentId;
    }
    
    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }
    
    public String getExamId() {
        return examId;
    }
    
    public void setExamId(String examId) {
        this.examId = examId;
    }
    
    public double getGrade() {
        return grade;
    }
    
    public void setGrade(double grade) {
        this.grade = grade;
    }
    
    public static boolean commitToFile() {
        return FManger.write(gradeFileName, Grades);
    }
    
    public static void loadFromFile() {
        Grades = (ArrayList<Grade>) FManger.read(gradeFileName);
        if (Grades == null) {
            Grades = new ArrayList<Grade>();
        }
    }
    
    @Override
    public String toString() {
        Student student = new Student().searchStudentById(studentId);
        return "Student: " + student.getFName() + " " + student.getLName() + 
               " (ID: " + studentId + "), Exam ID: " + examId + 
               ", Grade: " + grade;
    }
}
