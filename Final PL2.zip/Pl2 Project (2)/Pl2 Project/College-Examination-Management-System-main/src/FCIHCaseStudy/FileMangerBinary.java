package FCIHCaseStudy;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;


public class FileMangerBinary implements Serializable {

    public boolean write(String FilePath, Object data) {
        ObjectOutputStream writer = null;
        
        try {
            System.out.print("\nWriting to " + FilePath);
            
            // Use absolute path if relative path is provided
            java.io.File file = new java.io.File(FilePath);
            if (!file.isAbsolute()) {
                file = new java.io.File(System.getProperty("user.dir"), FilePath);
                System.out.println("\nConverting to absolute path: " + file.getAbsolutePath());
            }
            
            // Create directories if they don't exist
            java.io.File parentDir = file.getParentFile();
            if (parentDir != null && !parentDir.exists()) {
                boolean dirCreated = parentDir.mkdirs();
                if (dirCreated) {
                    System.out.println("Created directory: " + parentDir.getAbsolutePath());
                } else {
                    System.out.println("Failed to create directory: " + parentDir.getAbsolutePath());
                    return false;
                }
            }
            
            writer = new ObjectOutputStream(new FileOutputStream(file));
            writer.writeObject(data);
            System.out.println(" ... Done! ");
            return true;
            
        } catch (FileNotFoundException e) {
            System.out.println("\nError: File not found or cannot be created: " + FilePath);
            System.out.println("Details: " + e.getMessage());
            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("\nError writing to file: " + FilePath);
            System.out.println("Details: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    System.out.println("Error closing file: " + FilePath);
                    e.printStackTrace();
                }
            }
        }
        
        return false;
    }

    public Object read(String FilePath) {
        Object Result = null;
        ObjectInputStream Reader = null;
        
        try {
            // Use absolute path if relative path is provided
            java.io.File file = new java.io.File(FilePath);
            if (!file.isAbsolute()) {
                file = new java.io.File(System.getProperty("user.dir"), FilePath);
                System.out.println("Converting to absolute path: " + file.getAbsolutePath());
            }
            
            System.out.println("Reading from " + file.getAbsolutePath());
            
            // Check if file exists before attempting to read
            if (!file.exists()) {
                System.out.println("File does not exist: " + file.getAbsolutePath());
                return null;
            }
            
            Reader = new ObjectInputStream(new FileInputStream(file));
            Result = Reader.readObject();
            System.out.println("Successfully read data from " + file.getAbsolutePath());
            
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + FilePath);
            System.out.println("Details: " + e.getMessage());
            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("IO Error reading from " + FilePath);
            System.out.println("Details: " + e.getMessage());
            e.printStackTrace();
        } catch (ClassNotFoundException ex) {
            System.out.println("Class not found error when deserializing from " + FilePath);
            System.out.println("Details: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            if (Reader != null) {
                try {
                    Reader.close();
                } catch (IOException e) {
                    System.out.println("Error closing file: " + FilePath);
                    e.printStackTrace();
                }
            }
        }
        return Result;
    }
}
