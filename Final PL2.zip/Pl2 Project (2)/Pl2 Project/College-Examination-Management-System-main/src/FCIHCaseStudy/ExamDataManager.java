package FCIHCaseStudy;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;


public class ExamDataManager {
    
    /**
     * Export exams to a CSV file
     * @param exams List of exams to export
     * @return true if export was successful, false otherwise
     */
    public static boolean exportExamsToCSV(ArrayList<Exam> exams) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Specify a file to save");
        fileChooser.setFileFilter(new FileNameExtensionFilter("CSV files (*.csv)", "csv"));
        
        int userSelection = fileChooser.showSaveDialog(null);
        
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            String filePath = fileToSave.getAbsolutePath();
            if (!filePath.toLowerCase().endsWith(".csv")) {
                filePath += ".csv";
            }
            
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
                // Write header
                writer.write("ID,Name,Subject,Duration,MaxGrade,Question1,Question2,Question3,Question4,Answer1,Answer2,Answer3,Answer4");
                writer.newLine();
                
                // Write data
                for (Exam exam : exams) {
                    StringBuilder line = new StringBuilder();
                    line.append(exam.getEId()).append(",");
                    line.append(escapeCsv(exam.getEName())).append(",");
                    line.append(escapeCsv(exam.getSubjectName())).append(",");
                    line.append(exam.getDuration()).append(",");
                    line.append(exam.getMaxGrade()).append(",");
                    line.append(escapeCsv(exam.getQ1())).append(",");
                    line.append(escapeCsv(exam.getQ2())).append(",");
                    line.append(escapeCsv(exam.getQ3())).append(",");
                    line.append(escapeCsv(exam.getQ4())).append(",");
                    line.append(escapeCsv(exam.getCorrectAnswer1())).append(",");
                    line.append(escapeCsv(exam.getCorrectAnswer2())).append(",");
                    line.append(escapeCsv(exam.getCorrectAnswer3())).append(",");
                    line.append(escapeCsv(exam.getCorrectAnswer4()));
                    
                    writer.write(line.toString());
                    writer.newLine();
                }
                
                JOptionPane.showMessageDialog(null, 
                    "Exams successfully exported to " + filePath, 
                    "Export Successful", 
                    JOptionPane.INFORMATION_MESSAGE);
                
                return true;
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, 
                    "Error exporting exams: " + e.getMessage(), 
                    "Export Error", 
                    JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }
        
        return false;
    }
    
    /**
     * Import exams from a CSV file
     * @return List of imported exams, or null if import failed
     */
    public static ArrayList<Exam> importExamsFromCSV() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Select CSV file to import");
        fileChooser.setFileFilter(new FileNameExtensionFilter("CSV files (*.csv)", "csv"));
        
        int userSelection = fileChooser.showOpenDialog(null);
        
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToLoad = fileChooser.getSelectedFile();
            ArrayList<Exam> importedExams = new ArrayList<>();
            
            try (BufferedReader reader = new BufferedReader(new FileReader(fileToLoad))) {
                // Skip header
                String line = reader.readLine();
                
                // Read data
                while ((line = reader.readLine()) != null) {
                    String[] data = parseCSVLine(line);
                    
                    if (data.length >= 13) {
                        Exam exam = new Exam();
                        exam.setEId(data[0]);
                        exam.setEName(data[1]);
                        exam.setSubjectName(data[2]);
                        exam.setDuration(Integer.parseInt(data[3]));
                        exam.setMaxGrade(Double.parseDouble(data[4]));
                        exam.setQ1(data[5]);
                        exam.setQ2(data[6]);
                        exam.setQ3(data[7]);
                        exam.setQ4(data[8]);
                        exam.setCorrectAnswer1(data[9]);
                        exam.setCorrectAnswer2(data[10]);
                        exam.setCorrectAnswer3(data[11]);
                        exam.setCorrectAnswer4(data[12]);
                        
                        importedExams.add(exam);
                    }
                }
                
                JOptionPane.showMessageDialog(null, 
                    importedExams.size() + " exams successfully imported", 
                    "Import Successful", 
                    JOptionPane.INFORMATION_MESSAGE);
                
                return importedExams;
            } catch (IOException | NumberFormatException e) {
                JOptionPane.showMessageDialog(null, 
                    "Error importing exams: " + e.getMessage(), 
                    "Import Error", 
                    JOptionPane.ERROR_MESSAGE);
                return null;
            }
        }
        
        return null;
    }
    
    /**
     * Parse a CSV line properly handling quoted fields
     * @param line The CSV line to parse
     * @return Array of parsed values
     */
    private static String[] parseCSVLine(String line) {
        ArrayList<String> result = new ArrayList<>();
        StringBuilder currentField = new StringBuilder();
        boolean inQuotes = false;
        
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            
            if (c == '"') {
                inQuotes = !inQuotes;
            } else if (c == ',' && !inQuotes) {
                result.add(currentField.toString());
                currentField = new StringBuilder();
            } else {
                currentField.append(c);
            }
        }
        
        result.add(currentField.toString());
        return result.toArray(new String[0]);
    }
    
    /**
     * Escape a string for CSV format
     * @param input The string to escape
     * @return Escaped string
     */
    private static String escapeCsv(String input) {
        if (input == null) {
            return "";
        }
        
        if (input.contains(",") || input.contains("\"") || input.contains("\n")) {
            return "\"" + input.replace("\"", "\"\"") + "\"";
        }
        
        return input;
    }
}
