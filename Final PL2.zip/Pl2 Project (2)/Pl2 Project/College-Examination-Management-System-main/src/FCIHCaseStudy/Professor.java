package FCIHCaseStudy;

import java.io.Serializable;
import java.util.ArrayList;


public class Professor extends Staff implements Serializable {
    
    private static final long serialVersionUID = 2070913079793651983L;

    private String officeHours;

    private final String professorFileName = "Professor.bin";

    public static ArrayList<Professor> Professors = new ArrayList<Professor>();

    public Professor() {
    }

    public Professor(String user, String pass, int id, String fname, String lname, int age, double salary, String officeHours, Department dept) {
        super(user, pass, id, fname, lname, age, salary, dept);

        this.officeHours = officeHours;
    }

    public void setOfficeHours(String h) {
        this.officeHours = h;
    }

    public String getOfficeHours() {
        return this.officeHours;
    }

    public boolean addProf() {
        loadFromFile();
        Professors.add(this);
        return commitToFile();
    }

    public boolean commitToFile() {
        return FManger.write(professorFileName, Professors);
    }

    public void loadFromFile() {
        Professors = (ArrayList<Professor>) FManger.read(professorFileName);
        if (Professors == null) {
            Professors = new ArrayList<Professor>();
        }
    }

    private int getProfIndex(int id) {
        for (int i = 0; i < Professors.size(); i++) {
            if (Professors.get(i).getID() == id) {
                return i;
            }
        }

        return -1;
    }

    public Professor searchProfById(int id) {
        Professor temp = new Professor();
        loadFromFile();
        int index = getProfIndex(id);
        if (index != -1) {
            return Professors.get(index);
        } else {
            return temp;
        }
    }

    public ArrayList<Professor> listProfs() {
        loadFromFile();
        return Professors;
    }

    public boolean updateProf() {
        loadFromFile();
        int index = getProfIndex(this.getID());

        if (index != -1) {
            Professors.set(index, this);

            return commitToFile();
        }

        return false;
    }

    public boolean deleteProf(int id) {
        loadFromFile();
        int index = getProfIndex(id);

        if (index != -1) {
            Professors.remove(index);

            return commitToFile();
        }

        return false;
    }

    @Override
    public String toString() {
        return "\nI'm Prof : " + fname + " " + lname + "\n" + "ID : " + id + " Age : " + age + " Salary : " + officeHours + "\n" + "Dept. : " + myDept.getDeptName() + "\nUserName: " + userName + "\t Password: " + pass + "\n";
    }

    public void teach() {
        System.out.println("I'm Teaching all Lectures !");
    }
    
    /**
     * Add a grade for a student in an exam
     * @param studentId The ID of the student
     * @param examId The ID of the exam
     * @param grade The grade value
     * @return true if grade was added successfully, false otherwise
     */
    public boolean addGrade(int studentId, String examId, double grade) {
        // Validate student exists
        Student student = new Student().searchStudentById(studentId);
        if (student.getID() == 0) {
            return false; // Student not found
        }
        
        // Validate grade is within range
        Exam exam = new Exam();
        if (grade < 0 || grade > exam.getMaxGrade()) {
            return false; // Invalid grade
        }
        
        // Check if grade already exists
        Grade.loadFromFile();
        for (Grade g : Grade.Grades) {
            if (g.getStudentId() == studentId && g.getExamId().equals(examId)) {
                // Grade already exists, update it
                g.setGrade(grade);
                return Grade.commitToFile();
            }
        }
        
        // Add new grade
        Grade newGrade = new Grade(studentId, examId, grade);
        Grade.Grades.add(newGrade);
        return Grade.commitToFile();
    }
    
    /**
     * Delete a grade for a student in an exam
     * @param studentId The ID of the student
     * @param examId The ID of the exam
     * @return true if grade was deleted successfully, false otherwise
     */
    public boolean deleteGrade(int studentId, String examId) {
        Grade.loadFromFile();
        for (int i = 0; i < Grade.Grades.size(); i++) {
            Grade g = Grade.Grades.get(i);
            if (g.getStudentId() == studentId && g.getExamId().equals(examId)) {
                Grade.Grades.remove(i);
                return Grade.commitToFile();
            }
        }
        return false; // Grade not found
    }
    
    /**
     * Get all grades for a specific student
     * @param studentId The ID of the student
     * @return ArrayList of grades for the student
     */
    public ArrayList<Grade> getStudentGrades(int studentId) {
        ArrayList<Grade> studentGrades = new ArrayList<>();
        Grade.loadFromFile();
        for (Grade g : Grade.Grades) {
            if (g.getStudentId() == studentId) {
                studentGrades.add(g);
            }
        }
        return studentGrades;
    }
    
    /**
     * Get all grades for a specific exam
     * @param examId The ID of the exam
     * @return ArrayList of grades for the exam
     */
    public ArrayList<Grade> getExamGrades(String examId) {
        ArrayList<Grade> examGrades = new ArrayList<>();
        Grade.loadFromFile();
        for (Grade g : Grade.Grades) {
            if (g.getExamId().equals(examId)) {
                examGrades.add(g);
            }
        }
        return examGrades;
    }
    
    /**
     * Get all grades in the system
     * @return ArrayList of all grades
     */
    public ArrayList<Grade> getAllGrades() {
        Grade.loadFromFile();
        return Grade.Grades;
    }

    /**
     * Add a new exam to the system
     * @param exam The exam to add
     * @return true if exam was added successfully, false otherwise
     */
    public boolean addExam(Exam exam) {
        return exam.addExam();
    }
    
    /**
     * Update an existing exam in the system
     * @param exam The exam with updated information
     * @return true if exam was updated successfully, false otherwise
     */
    public boolean updateExam(Exam exam) {
        return exam.updateExam();
    }
    
    /**
     * Delete an exam from the system
     * @param examId The ID of the exam to delete
     * @return true if exam was deleted successfully, false otherwise
     */
    public boolean deleteExam(String examId) {
        Exam exam = new Exam().searchExamById(examId);
        if (exam != null) {
            return exam.deleteExam();
        }
        return false;
    }
    
    /**
     * Get all exams in the system
     * @return ArrayList of all exams
     */
    public ArrayList<Exam> getAllExams() {
        Exam exam = new Exam();
        return exam.getAllExams();
    }
    
    /**
     * Search for an exam by its ID
     * @param examId The ID of the exam to search for
     * @return The exam if found, null otherwise
     */
    public Exam getExamById(String examId) {
        return new Exam().searchExamById(examId);
    }

    @Override
    public boolean login(String userName, String Pass) {
        loadFromFile();
        for (Professor x : Professors) {
            if (userName.equals(x.userName) && Pass.equals(x.pass)) {
                return true;
            }
        }
        return false;
    }
}
