package FCIHCaseStudy;

import java.io.Serializable;
import java.util.ArrayList;


public class Exam implements Serializable {
    private static final long serialVersionUID = 1L;

    private String EName, EId, q1, q2, q3, q4;
    private String correctAnswer1, correctAnswer2, correctAnswer3, correctAnswer4;
    private int duration; // in minutes
    private double MaxGrade;
    private String subjectName;

    private static FileMangerBinary FManger = new FileMangerBinary();
    private static final String ExamsFileName = "Exams.bin";
    public static ArrayList<Exam> Exams = new ArrayList<Exam>();
    
    // Track if the file has been loaded already
    private static boolean fileLoaded = false;

    public Exam() {
    }

    public Exam(String EName, String EId, double MaxGrade, String q1, String q2, String q3, String q4) {
        this.EName = EName;
        this.EId = EId;
        this.MaxGrade = MaxGrade;
        this.q1 = q1; 
        this.q2 = q2;
        this.q3 = q3;
        this.q4 = q4;
        this.duration = 60; // Default 60 minutes
    }
    
    public Exam(String EName, String EId, double MaxGrade, String q1, String q2, String q3, String q4, 
                String correctAnswer1, String correctAnswer2, String correctAnswer3, String correctAnswer4, 
                int duration, String subjectName) {
        this.EName = EName;
        this.EId = EId;
        this.MaxGrade = MaxGrade;
        this.q1 = q1; 
        this.q2 = q2;
        this.q3 = q3;
        this.q4 = q4;
        this.correctAnswer1 = correctAnswer1;
        this.correctAnswer2 = correctAnswer2;
        this.correctAnswer3 = correctAnswer3;
        this.correctAnswer4 = correctAnswer4;
        this.duration = duration;
        this.subjectName = subjectName;
    }

    public void setEName(String EName) {
        this.EName = EName;
    }

    public void setEId(String EId) {
        this.EId = EId;
    }

    public void setMaxGrade(double MaxGrade) {
        this.MaxGrade = MaxGrade;
    }

    public String getQ1() {
        return q1;
    }

    public void setQ1(String q1) {
        this.q1 = q1;
    }

    public String getQ2() {
        return q2;
    }

    public void setQ2(String q2) {
        this.q2 = q2;
    }

    public String getQ3() {
        return q3;
    }

    public void setQ3(String q3) {
        this.q3 = q3;
    }

    public String getQ4() {
        return q4;
    }

    public void setQ4(String q4) {
        this.q4 = q4;
    }
    
    public String getCorrectAnswer1() {
        return correctAnswer1;
    }

    public void setCorrectAnswer1(String correctAnswer1) {
        this.correctAnswer1 = correctAnswer1;
    }

    public String getCorrectAnswer2() {
        return correctAnswer2;
    }

    public void setCorrectAnswer2(String correctAnswer2) {
        this.correctAnswer2 = correctAnswer2;
    }

    public String getCorrectAnswer3() {
        return correctAnswer3;
    }

    public void setCorrectAnswer3(String correctAnswer3) {
        this.correctAnswer3 = correctAnswer3;
    }

    public String getCorrectAnswer4() {
        return correctAnswer4;
    }

    public void setCorrectAnswer4(String correctAnswer4) {
        this.correctAnswer4 = correctAnswer4;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }
    
    public String getSubjectName() {
        return subjectName;
    }

    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }

    public String getEName() {
        return this.EName;
    }

    public String getEId() {
        return this.EId;
    }

    public double getMaxGrade() {
        return this.MaxGrade;
    }

    public boolean addExam() {
        try {
            loadFromFile();
            // Check if an exam with this ID already exists
            for (Exam e : Exams) {
                if (e.getEId().equals(this.EId)) {
                    System.out.println("Exam with ID " + this.EId + " already exists.");
                    return false;
                }
            }
            Exams.add(this);
            return commitToFile();
        } catch (Exception e) {
            System.out.println("Error adding exam: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean updateExam() {
        try {
            loadFromFile();
            for (int i = 0; i < Exams.size(); i++) {
                if (Exams.get(i).getEId().equals(this.EId)) {
                    Exams.set(i, this);
                    return commitToFile();
                }
            }
            System.out.println("Exam with ID " + this.EId + " not found for update.");
            return false;
        } catch (Exception e) {
            System.out.println("Error updating exam: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean deleteExam() {
        try {
            loadFromFile();
            for (int i = 0; i < Exams.size(); i++) {
                if (Exams.get(i).getEId().equals(this.EId)) {
                    Exams.remove(i);
                    return commitToFile();
                }
            }
            System.out.println("Exam with ID " + this.EId + " not found for deletion.");
            return false;
        } catch (Exception e) {
            System.out.println("Error deleting exam: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean commitToFile() {
        try {
            boolean result = FManger.write(ExamsFileName, Exams);
            if (!result) {
                System.out.println("Failed to write exams to file.");
            }
            return result;
        } catch (Exception e) {
            System.out.println("Error committing exams to file: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    public void loadFromFile() {
        try {
            // Only load from file if not already loaded or force reload
            if (!fileLoaded) {
                Object result = FManger.read(ExamsFileName);
                if (result != null) {
                    Exams = (ArrayList<Exam>) result;
                    fileLoaded = true;
                } else {
                    // If file doesn't exist or is empty, initialize with empty list
                    Exams = new ArrayList<Exam>();
                    fileLoaded = true;
                }
            }
        } catch (Exception e) {
            System.out.println("Error loading exams from file: " + e.getMessage());
            e.printStackTrace();
            Exams = new ArrayList<Exam>();
        }
    }
    
    public Exam searchExamById(String id) {
        try {
            loadFromFile();
            for (Exam exam : Exams) {
                if (exam.getEId().equals(id)) {
                    return exam;
                }
            }
            System.out.println("Exam with ID " + id + " not found.");
            return null; // Return null if not found
        } catch (Exception e) {
            System.out.println("Error searching for exam: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
    
    public ArrayList<Exam> getAllExams() {
        try {
            loadFromFile();
            return new ArrayList<>(Exams); // Return a copy to prevent modification of the original list
        } catch (Exception e) {
            System.out.println("Error getting all exams: " + e.getMessage());
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    
    @Override
    public String toString() {
        return "Exam Name: " + EName + "\nExam ID: " + EId + 
               "\nSubject: " + (subjectName != null ? subjectName : "Not specified") +
               "\nDuration: " + duration + " minutes" +
               "\nMax Grade: " + MaxGrade;
    }
    
    /**
     * Calculate the grade for a student based on their answers
     * @param answers Array of student answers [answer1, answer2, answer3, answer4]
     * @return The calculated grade
     */
    public double calculateGrade(String[] answers) {
        double grade = 0;
        double pointsPerQuestion = MaxGrade / 4;
        
        if (answers.length >= 4) {
            if (correctAnswer1 != null && correctAnswer1.equals(answers[0])) {
                grade += pointsPerQuestion;
            }
            if (correctAnswer2 != null && correctAnswer2.equals(answers[1])) {
                grade += pointsPerQuestion;
            }
            if (correctAnswer3 != null && correctAnswer3.equals(answers[2])) {
                grade += pointsPerQuestion;
            }
            if (correctAnswer4 != null && correctAnswer4.equals(answers[3])) {
                grade += pointsPerQuestion;
            }
        }
        
        return grade;
    }

}
