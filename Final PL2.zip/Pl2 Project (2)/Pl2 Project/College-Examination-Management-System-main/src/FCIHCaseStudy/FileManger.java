package FCIHCaseStudy;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;


public class FileManger implements Serializable {

    public boolean write(String Query, String FilePath, boolean appendType) {
        PrintWriter writer = null;
        try {
            System.out.print("\nWriting to " + FilePath + (appendType ? " (append mode)" : " (overwrite mode)"));
            writer = new PrintWriter(new FileWriter(new File(FilePath), appendType));
            writer.println(Query);
            writer.flush(); // Ensure data is written immediately
            System.out.println(" ... Done!");
            return true;
        } catch (IOException e) {
            System.out.println("\nError writing to file: " + FilePath);
            System.out.println(e.getMessage());
            return false;
        } finally {
            if (writer != null) {
                writer.close();
            }
        }
    }

    public ArrayList<Object> read(String FilePath) {
        Scanner Reader = null;
        try {
            System.out.println("Reading from " + FilePath);
            Reader = new Scanner(new File(FilePath));

            if (FilePath.equals("Students.txt")) {

                ArrayList<Student> Students = new ArrayList<Student>();
                Student x;

                while (Reader.hasNext()) {

                    x = new Student();
                    String Line = Reader.nextLine();
                    String[] seprated = Line.split("@");

                    // 20140011@Ahmed@Ali@20@2@3.5@CS@STU_1@12345678@
                    x.setID(Integer.parseInt(seprated[0]));
                    x.setFName(seprated[1]);
                    x.setLName(seprated[2]);
                    x.setAge(Integer.parseInt(seprated[3]));
                    x.setLevel(Integer.parseInt(seprated[4]));
                    x.setGPA(Double.parseDouble(seprated[5]));

                    if (seprated[6].equals("CS")) {
                        x.setDept(Main.cs);
                    } else if (seprated[6].equals("IS")) {
                        x.setDept(Main.is);
                    } else if (seprated[6].equals("IT")) {
                        x.setDept(Main.it);
                    } else if (seprated[6].equals("SW")) {
                        x.setDept(Main.sw);
                    }

                    x.setUserName(seprated[7]);
                    x.setPass(seprated[8]);

                    Students.add(x);
                }

                return (ArrayList<Object>) (Object) Students;

            } else if (FilePath.equals("Professor.txt")) {

                ArrayList<Professor> Professors = new ArrayList<Professor>();
                Professor x;

                while (Reader.hasNext()) {

                    x = new Professor();
                    String Line = Reader.nextLine();
                    String[] seprated = Line.split("@");

                    // 1@Ayman@Ezzat@30@8000.0@Mon 12pm to 2pm@CS@Prof_1@12345678@
                    x.setID(Integer.parseInt(seprated[0]));
                    x.setFName(seprated[1]);
                    x.setLName(seprated[2]);
                    x.setAge(Integer.parseInt(seprated[3]));
                    x.setSalary(Double.parseDouble(seprated[4]));
                    x.setOfficeHours(seprated[5]);

                    if (seprated[6].equals("CS")) {
                        x.setDept(Main.cs);
                    } else if (seprated[6].equals("IS")) {
                        x.setDept(Main.is);
                    } else if (seprated[6].equals("IT")) {
                        x.setDept(Main.it);
                    } else if (seprated[6].equals("SW")) {
                        x.setDept(Main.sw);
                    }

                    x.setUserName(seprated[7]);
                    x.setPass(seprated[8]);

                    Professors.add(x);
                }

                return (ArrayList<Object>) (Object) Professors;
            } else if (FilePath.equals("Courses.txt")) {

                ArrayList<Course> Courses = new ArrayList<Course>();
                Course x;

                while (Reader.hasNext()) {

                    x = new Course();
                    String Line = Reader.nextLine();
                    String[] seprated = Line.split("@");

                    // PL2@CS213@100@
                    x.setCname(seprated[0]);
                    x.setCId(seprated[1]);
                    x.setCreditHours(Integer.parseInt(seprated[2]));

                    Courses.add(x);
                }

                return (ArrayList<Object>) (Object) Courses;

            } else {
                return null;
            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + FilePath);
            System.out.println(e.getMessage());
            return null;
        } finally {
            if (Reader != null) {
                Reader.close();
            }
        }
    }

}
