package FCIH_GUI;

import FCIHCaseStudy.Exam;
import FCIHCaseStudy.Professor;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 * Frame for professors to manage exams (add, edit, delete)
 */
public class ProfessorExamManagementFrame extends JFrame implements ActionListener {
    
    private JTable examTable;
    private DefaultTableModel tableModel;
    private JButton btnAdd, btnEdit, btnDelete, btnRefresh, btnBack;
    private JComboBox<String> examIdComboBox;
    
    private Professor professor;
    
    public ProfessorExamManagementFrame(Professor professor) {
        super("Exam Management - Professor");
        this.professor = professor;
        
        // Set up the frame
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        // Create main panel with border layout
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Create table to display exams
        String[] columns = {"ID", "Name", "Subject", "Duration", "Max Grade"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table non-editable
            }
        };
        
        examTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(examTable);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        
        // Create panel for buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        
        btnAdd = new JButton("Add Exam");
        btnEdit = new JButton("Edit Exam");
        btnDelete = new JButton("Delete Exam");
        btnRefresh = new JButton("Refresh");
        btnBack = new JButton("Back");
        
        // Add action listeners
        btnAdd.addActionListener(this);
        btnEdit.addActionListener(this);
        btnDelete.addActionListener(this);
        btnRefresh.addActionListener(this);
        btnBack.addActionListener(this);
        
        // Add buttons to panel
        buttonPanel.add(btnAdd);
        buttonPanel.add(btnEdit);
        buttonPanel.add(btnDelete);
        buttonPanel.add(btnRefresh);
        buttonPanel.add(btnBack);
        
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        // Add the main panel to the frame
        add(mainPanel);
        
        // Load exams into table
        loadExams();
    }
    
    private void loadExams() {
        // Clear the table
        tableModel.setRowCount(0);
        
        // Get all exams
        ArrayList<Exam> exams = professor.getAllExams();
        
        // Add exams to table
        for (Exam exam : exams) {
            Object[] row = {
                exam.getEId(),
                exam.getEName(),
                exam.getSubjectName(),
                exam.getDuration(),
                exam.getMaxGrade()
            };
            tableModel.addRow(row);
        }
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnAdd) {
            showAddExamDialog();
        } else if (e.getSource() == btnEdit) {
            int selectedRow = examTable.getSelectedRow();
            if (selectedRow >= 0) {
                String examId = (String) tableModel.getValueAt(selectedRow, 0);
                Exam exam = professor.getExamById(examId);
                if (exam != null) {
                    showEditExamDialog(exam);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please select an exam to edit.", "No Selection", JOptionPane.WARNING_MESSAGE);
            }
        } else if (e.getSource() == btnDelete) {
            int selectedRow = examTable.getSelectedRow();
            if (selectedRow >= 0) {
                String examId = (String) tableModel.getValueAt(selectedRow, 0);
                int confirm = JOptionPane.showConfirmDialog(this, 
                    "Are you sure you want to delete exam " + examId + "?", 
                    "Confirm Deletion", 
                    JOptionPane.YES_NO_OPTION);
                
                if (confirm == JOptionPane.YES_OPTION) {
                    boolean success = professor.deleteExam(examId);
                    if (success) {
                        JOptionPane.showMessageDialog(this, "Exam deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                        loadExams();
                    } else {
                        JOptionPane.showMessageDialog(this, "Failed to delete exam.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please select an exam to delete.", "No Selection", JOptionPane.WARNING_MESSAGE);
            }
        } else if (e.getSource() == btnRefresh) {
            loadExams();
        } else if (e.getSource() == btnBack) {
            dispose();
        }
    }
    
    private void showAddExamDialog() {
        JFrame addFrame = new JFrame("Add New Exam");
        addFrame.setSize(500, 500);
        addFrame.setLocationRelativeTo(this);
        
        JPanel panel = new JPanel(new GridLayout(12, 2, 5, 5));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Create form fields
        JTextField txtId = new JTextField();
        JTextField txtName = new JTextField();
        JTextField txtSubject = new JTextField();
        JTextField txtDuration = new JTextField("60");
        JTextField txtMaxGrade = new JTextField("20");
        JTextField txtQ1 = new JTextField();
        JTextField txtQ2 = new JTextField();
        JTextField txtQ3 = new JTextField();
        JTextField txtQ4 = new JTextField();
        JTextField txtA1 = new JTextField();
        JTextField txtA2 = new JTextField();
        JTextField txtA3 = new JTextField();
        JTextField txtA4 = new JTextField();
        
        // Add fields to panel
        panel.add(new JLabel("Exam ID:"));
        panel.add(txtId);
        panel.add(new JLabel("Exam Name:"));
        panel.add(txtName);
        panel.add(new JLabel("Subject:"));
        panel.add(txtSubject);
        panel.add(new JLabel("Duration (minutes):"));
        panel.add(txtDuration);
        panel.add(new JLabel("Max Grade:"));
        panel.add(txtMaxGrade);
        panel.add(new JLabel("Question 1:"));
        panel.add(txtQ1);
        panel.add(new JLabel("Question 2:"));
        panel.add(txtQ2);
        panel.add(new JLabel("Question 3:"));
        panel.add(txtQ3);
        panel.add(new JLabel("Question 4:"));
        panel.add(txtQ4);
        panel.add(new JLabel("Answer 1:"));
        panel.add(txtA1);
        panel.add(new JLabel("Answer 2:"));
        panel.add(txtA2);
        panel.add(new JLabel("Answer 3:"));
        panel.add(txtA3);
        panel.add(new JLabel("Answer 4:"));
        panel.add(txtA4);
        
        // Create buttons
        JButton btnSave = new JButton("Save");
        JButton btnCancel = new JButton("Cancel");
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(btnSave);
        buttonPanel.add(btnCancel);
        
        // Add panels to frame
        addFrame.setLayout(new BorderLayout());
        addFrame.add(panel, BorderLayout.CENTER);
        addFrame.add(buttonPanel, BorderLayout.SOUTH);
        
        // Add action listeners
        btnSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Validate input
                    String id = txtId.getText().trim();
                    String name = txtName.getText().trim();
                    String subject = txtSubject.getText().trim();
                    int duration = Integer.parseInt(txtDuration.getText().trim());
                    double maxGrade = Double.parseDouble(txtMaxGrade.getText().trim());
                    String q1 = txtQ1.getText().trim();
                    String q2 = txtQ2.getText().trim();
                    String q3 = txtQ3.getText().trim();
                    String q4 = txtQ4.getText().trim();
                    String a1 = txtA1.getText().trim();
                    String a2 = txtA2.getText().trim();
                    String a3 = txtA3.getText().trim();
                    String a4 = txtA4.getText().trim();
                    
                    if (id.isEmpty() || name.isEmpty() || subject.isEmpty() || 
                        q1.isEmpty() || q2.isEmpty() || q3.isEmpty() || q4.isEmpty() ||
                        a1.isEmpty() || a2.isEmpty() || a3.isEmpty() || a4.isEmpty()) {
                        JOptionPane.showMessageDialog(addFrame, "All fields are required.", "Validation Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    
                    // Create new exam
                    Exam exam = new Exam(name, id, maxGrade, q1, q2, q3, q4, a1, a2, a3, a4, duration, subject);
                    
                    // Add exam
                    boolean success = professor.addExam(exam);
                    
                    if (success) {
                        JOptionPane.showMessageDialog(addFrame, "Exam added successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                        addFrame.dispose();
                        loadExams();
                    } else {
                        JOptionPane.showMessageDialog(addFrame, "Failed to add exam. ID may already exist.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(addFrame, "Invalid number format. Please check duration and max grade.", "Input Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        btnCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addFrame.dispose();
            }
        });
        
        addFrame.setVisible(true);
    }
    
    private void showEditExamDialog(Exam exam) {
        JFrame editFrame = new JFrame("Edit Exam");
        editFrame.setSize(500, 500);
        editFrame.setLocationRelativeTo(this);
        
        JPanel panel = new JPanel(new GridLayout(12, 2, 5, 5));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Create form fields
        JTextField txtId = new JTextField(exam.getEId());
        txtId.setEditable(false); // ID should not be editable
        JTextField txtName = new JTextField(exam.getEName());
        JTextField txtSubject = new JTextField(exam.getSubjectName());
        JTextField txtDuration = new JTextField(String.valueOf(exam.getDuration()));
        JTextField txtMaxGrade = new JTextField(String.valueOf(exam.getMaxGrade()));
        JTextField txtQ1 = new JTextField(exam.getQ1());
        JTextField txtQ2 = new JTextField(exam.getQ2());
        JTextField txtQ3 = new JTextField(exam.getQ3());
        JTextField txtQ4 = new JTextField(exam.getQ4());
        JTextField txtA1 = new JTextField(exam.getCorrectAnswer1());
        JTextField txtA2 = new JTextField(exam.getCorrectAnswer2());
        JTextField txtA3 = new JTextField(exam.getCorrectAnswer3());
        JTextField txtA4 = new JTextField(exam.getCorrectAnswer4());
        
        // Add fields to panel
        panel.add(new JLabel("Exam ID:"));
        panel.add(txtId);
        panel.add(new JLabel("Exam Name:"));
        panel.add(txtName);
        panel.add(new JLabel("Subject:"));
        panel.add(txtSubject);
        panel.add(new JLabel("Duration (minutes):"));
        panel.add(txtDuration);
        panel.add(new JLabel("Max Grade:"));
        panel.add(txtMaxGrade);
        panel.add(new JLabel("Question 1:"));
        panel.add(txtQ1);
        panel.add(new JLabel("Question 2:"));
        panel.add(txtQ2);
        panel.add(new JLabel("Question 3:"));
        panel.add(txtQ3);
        panel.add(new JLabel("Question 4:"));
        panel.add(txtQ4);
        panel.add(new JLabel("Answer 1:"));
        panel.add(txtA1);
        panel.add(new JLabel("Answer 2:"));
        panel.add(txtA2);
        panel.add(new JLabel("Answer 3:"));
        panel.add(txtA3);
        panel.add(new JLabel("Answer 4:"));
        panel.add(txtA4);
        
        // Create buttons
        JButton btnUpdate = new JButton("Update");
        JButton btnCancel = new JButton("Cancel");
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(btnUpdate);
        buttonPanel.add(btnCancel);
        
        // Add panels to frame
        editFrame.setLayout(new BorderLayout());
        editFrame.add(panel, BorderLayout.CENTER);
        editFrame.add(buttonPanel, BorderLayout.SOUTH);
        
        // Add action listeners
        btnUpdate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Validate input
                    String id = txtId.getText().trim();
                    String name = txtName.getText().trim();
                    String subject = txtSubject.getText().trim();
                    int duration = Integer.parseInt(txtDuration.getText().trim());
                    double maxGrade = Double.parseDouble(txtMaxGrade.getText().trim());
                    String q1 = txtQ1.getText().trim();
                    String q2 = txtQ2.getText().trim();
                    String q3 = txtQ3.getText().trim();
                    String q4 = txtQ4.getText().trim();
                    String a1 = txtA1.getText().trim();
                    String a2 = txtA2.getText().trim();
                    String a3 = txtA3.getText().trim();
                    String a4 = txtA4.getText().trim();
                    
                    if (id.isEmpty() || name.isEmpty() || subject.isEmpty() || 
                        q1.isEmpty() || q2.isEmpty() || q3.isEmpty() || q4.isEmpty() ||
                        a1.isEmpty() || a2.isEmpty() || a3.isEmpty() || a4.isEmpty()) {
                        JOptionPane.showMessageDialog(editFrame, "All fields are required.", "Validation Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    
                    // Update exam
                    exam.setEName(name);
                    exam.setSubjectName(subject);
                    exam.setDuration(duration);
                    exam.setMaxGrade(maxGrade);
                    exam.setQ1(q1);
                    exam.setQ2(q2);
                    exam.setQ3(q3);
                    exam.setQ4(q4);
                    exam.setCorrectAnswer1(a1);
                    exam.setCorrectAnswer2(a2);
                    exam.setCorrectAnswer3(a3);
                    exam.setCorrectAnswer4(a4);
                    
                    boolean success = professor.updateExam(exam);
                    
                    if (success) {
                        JOptionPane.showMessageDialog(editFrame, "Exam updated successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                        editFrame.dispose();
                        loadExams();
                    } else {
                        JOptionPane.showMessageDialog(editFrame, "Failed to update exam.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(editFrame, "Invalid number format. Please check duration and max grade.", "Input Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        btnCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editFrame.dispose();
            }
        });
        
        editFrame.setVisible(true);
    }
}
