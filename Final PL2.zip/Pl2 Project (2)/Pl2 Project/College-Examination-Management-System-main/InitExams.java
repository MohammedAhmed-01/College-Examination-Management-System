import FCIHCaseStudy.Exam;
import FCIHCaseStudy.ExamInitializer;
import FCIHCaseStudy.FileMangerBinary;
import java.util.ArrayList;

/**
 * Utility class to initialize the Exams.bin file with sample data
 */
public class InitExams {
    public static void main(String[] args) {
        System.out.println("Initializing Exams.bin file with sample data...");
        
        // Use the ExamInitializer to initialize the Exams.bin file
        boolean success = ExamInitializer.initializeIfNeeded();
        
        if (success) {
            System.out.println("Exams.bin file initialized successfully!");
            
            // Print the exams that were created
            Exam exam = new Exam();
            exam.loadFromFile();
            ArrayList<Exam> exams = exam.getAllExams();
            
            System.out.println("Number of exams in file: " + exams.size());
            for (Exam e : exams) {
                System.out.println("----------------------------");
                System.out.println(e.toString());
            }
        } else {
            System.out.println("Failed to initialize Exams.bin file.");
        }
    }
}
